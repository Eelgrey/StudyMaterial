# BTS Info

BTS (Korean: 방탄소년단; RR: Bangtan Sonyeondan), also known as the Bangtan Boys, 
is a seven-member South Korean boy band that began formation in 2010 and debuted in 2013 under Big Hit Entertainment. 
The septet—composed of RM, Jin, Suga, J-Hope, Jimin, V, 
and Jungkook—co-writes and co-produces much of their own output.
